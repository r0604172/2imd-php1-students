-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2016 at 02:47 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `php1w32`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `titel` varchar(255) NOT NULL,
  `tekst` text NOT NULL,
  `datum` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `user_id`, `titel`, `tekst`, `datum`) VALUES
(1, 1, 'Test 1', 'Donec et augue sed urna posuere bibendum vel in erat. Curabitur volutpat est in velit viverra, quis pellentesque urna facilisis. Donec ut nisi a felis dictum congue. Nulla tristique nunc vel dignissim convallis. Aliquam in sapien dui. Donec id ipsum vel mauris lacinia ornare eu et metus. Duis quis congue tellus, a malesuada mauris.', '2016-03-03'),
(2, 1, 'Test 2', 'Donec et augue sed urna posuere bibendum vel in erat. Curabitur volutpat est in velit viverra, quis pellentesque urna facilisis. Donec ut nisi a felis dictum congue. Nulla tristique nunc vel dignissim convallis. Aliquam in sapien dui. Donec id ipsum vel mauris lacinia ornare eu et metus. Duis quis congue tellus, a malesuada mauris.', '2016-03-04'),
(3, 1, 'Test 3', 'Proin sagittis urna nibh, quis pharetra neque imperdiet ac. Ut nec erat risus. Mauris posuere; justo ac auctor laoreet, nunc ex fringilla massa, vel lacinia eros orci eu magna. Pellentesque rhoncus quis leo sit amet vulputate. Donec elit arcu, tempor a ex id, semper ullamcorper eros! Aenean tincidunt mi ut metus laoreet ultricies. Nullam vel est ullamcorper, pharetra purus quis, tincidunt arcu. Nam imperdiet a velit vel laoreet. Aenean at maximus ex!\r\n\r\nDonec sodales lacus tellus, in luctus lorem pellentesque at. Maecenas egestas diam eget neque varius dapibus! Aenean aliquet purus augue, et condimentum justo lobortis in. Cras condimentum massa dolor; vitae convallis erat dapibus at. Nullam congue libero eget risus varius, et hendrerit ligula vestibulum! Donec porta porta vestibulum. Nulla eu aliquam tellus. Donec gravida, erat posuere imperdiet lacinia, leo arcu suscipit mi, vitae tristique neque quam et elit. Nam quis ipsum nulla. Phasellus sit amet elementum purus. Donec ipsum lectus, volutpat id dignissim in, vulputate nec sem. Aliquam erat volutpat. Morbi tempor, felis vitae fringilla vestibulum, massa nulla pellentesque eros, vitae scelerisque risus ipsum sit amet ante. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur elementum dui neque, feugiat semper leo consequat in. Fusce lobortis, dolor id rutrum convallis, sem elit vehicula nulla, et ultrices nunc diam id justo.\r\n\r\nCurabitur efficitur auctor ante a sodales. Sed vel leo quam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nam massa libero, molestie id ante quis, accumsan fringilla nisl? Nam ullamcorper tincidunt lectus, eu semper lacus blandit ut. Aliquam pulvinar non nibh nec congue. Nulla a enim consequat, vestibulum velit nec, consectetur leo. Donec at libero odio. Maecenas nec lorem urna. Duis vitae elementum felis; eu hendrerit nulla. Cras sollicitudin nunc ac eros hendrerit, quis pretium nisi vestibulum. Proin ultrices fermentum sodales. Cras in dolor ac dolor commodo varius a quis arcu. Nunc eget commodo massa. Maecenas consectetur, augue a convallis consequat, dolor dui maximus dolor, ac hendrerit diam risus eu nibh. Vivamus fermentum, quam nec lacinia luctus, odio neque sollicitudin augue, et imperdiet eros urna ac dui.', '2016-03-05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `naam` varchar(50) NOT NULL,
  `paswoord` varchar(300) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `naam`, `paswoord`) VALUES
(1, 'Christophe', '$2y$12$U6jAR29BO8unxfdXlKWdhOtwCi56sgBJFP2rmyyAYYROyYuLkc2RK'),
(2, 'test', '$2y$12$Puv7FpLEP9G9wBUax3d63.yaZbCjqElYZON/wPL2Go5tiWjPrb.S6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `uniqueNaam` (`naam`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
